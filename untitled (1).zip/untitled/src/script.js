// script.js - handles animations, reveal on scroll, counters, small UX

document.addEventListener('DOMContentLoaded', () => {
  // simple scroll reveal using IntersectionObserver
  const revealEls = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        // once visible, unobserve to keep performance good
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealEls.forEach(el => io.observe(el));

  // animate header year
  document.getElementById('year').textContent = new Date().getFullYear();

  // counter animation
  const counters = document.querySelectorAll('.counter-num');
  counters.forEach(c => {
    const target = +c.getAttribute('data-target') || 0;
    let current = 0;
    const step = Math.max(1, Math.floor(target / 120));
    const animate = () => {
      current += step;
      if (current >= target) {
        c.textContent = target.toLocaleString();
      } else {
        c.textContent = current.toLocaleString();
        requestAnimationFrame(animate);
      }
    };
    // trigger when visible
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          animate();
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.6 });
    obs.observe(c);
  });

  // portrait subtle parallax on mouse move
  const portrait = document.getElementById('portrait');
  const wrap = portrait && portrait.closest('.portrait-wrap');
  if (portrait && wrap) {
    wrap.addEventListener('mousemove', (ev) => {
      const rect = wrap.getBoundingClientRect();
      const mx = (ev.clientX - rect.left) / rect.width - 0.5;
      const my = (ev.clientY - rect.top) / rect.height - 0.5;
      portrait.style.transform = `translate(${mx * 10}px, ${my * 6}px) scale(1.02)`;
    });
    wrap.addEventListener('mouseleave', () => {
      portrait.style.transform = 'translateY(6px) scale(1)';
    });
  }

  // CTA typing animation (small, decorative)
  (function ctaType(){
    const cta = document.querySelector('.hero-cta .btn-primary');
    if(!cta) return;
    const words = ['Hire me on Fiverr','Get a free sample','Start your audit'];
    let idx = 0, char = 0, forward = true;
    setInterval(() => {
      const w = words[idx];
      cta.textContent = w.slice(0, char) + (char % 2 ? '|' : '');
      if (forward) {
        char++;
        if (char > w.length) { forward = false; setTimeout(()=>forward=true, 900); idx = (idx+1)%words.length; char=0; }
      }
    }, 140);
  })();

  // contact form tiny UX - simulate send and open Fiverr in a new tab
  const sendBtn = document.getElementById('sendBtn');
  const contactForm = document.getElementById('contactForm');

  sendBtn && sendBtn.addEventListener('click', () => {
    const name = document.getElementById('clientName').value.trim();
    const urls = document.getElementById('targetUrls').value.trim();
    const format = document.getElementById('format').value;
    if (!name || !urls) {
      alert('Please add your name and at least one target URL or note.');
      return;
    }
    // Provide user feedback and then open Fiverr link
    sendBtn.textContent = 'Preparing message…';
    sendBtn.disabled = true;
    setTimeout(() => {
      sendBtn.textContent = 'Open Fiverr';
      window.open('YOUR_FIVERR_LINK_HERE', '_blank', 'noopener');
      sendBtn.disabled = false;
    }, 900);
  });

  // small sample download behavior
  const downloadSample = document.getElementById('downloadSample');
  if (downloadSample) {
    downloadSample.addEventListener('click', () => {
      // create tiny sample CSV and initiate download
      const sampleData = 'Domain,Technology,Email\nexample.com,Shopify,info@example.com\ncompetitor.com,WordPress,hello@competitor.com';
      const blob = new Blob([sampleData], {type:'text/csv'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'builtwith-sample-report.csv';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    });
  }

  // accessibility: focus outline on keyboard navigation
  (function keyboardFocusOutline(){
    function handleFirstTab(e) {
      if (e.key === 'Tab') {
        document.body.classList.add('show-focus');
        window.removeEventListener('keydown', handleFirstTab);
      }
    }
    window.addEventListener('keydown', handleFirstTab);
  })();
});
